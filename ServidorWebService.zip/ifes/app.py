from flask import Flask, jsonify
from flask_restful import Resource, Api
from scrapers import alura_motors
import json


app = Flask(__name__)
api = Api(app)


class Index(Resource):
    def get(self):
        return jsonify(alura_motors.get_all())



api.add_resource(Index, '/')



if __name__ == '__main__':
    app.run(debug=True)
