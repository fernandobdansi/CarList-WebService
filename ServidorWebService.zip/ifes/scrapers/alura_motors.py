from bs4 import BeautifulSoup
import requests_cache
import requests


requests_cache.install_cache('cache-scraping',
                             backend='sqlite',
                             expire_after=600)


def get_all():

    cards = []
    req = requests.get('https://alura-site-scraping.herokuapp.com/index.php')
    soup = BeautifulSoup(req.text, 'html.parser')
    pages = int(soup.find('span', class_='info-pages').get_text().split()[-1])

    for i in range(pages):
        req = requests.get('https://alura-site-scraping.herokuapp.com/index.php?page=' + str(i + 1))
        soup = BeautifulSoup(req.text, 'html.parser')

        anuncios = soup.find('div', {'id': 'container-cards'}).findAll('div', class_='card')

        for anuncio in anuncios:
            card = {}

            card['value'] = anuncio.find('p', {'class': 'txt-value'}).getText()

            infos = anuncio.find('div', {'class': 'body-card'}).findAll('p')
            for info in infos:
                card[info.get('class')[0].split('-')[-1]] = info.get_text()

            items = anuncio.find('div', {'class': 'body-card'}).ul.findAll('li')
            items.pop()
            acessorios = []
            for item in items:
                acessorios.append(item.get_text().replace('► ', ''))
            card['items'] = acessorios

            image = anuncio.find('div', {'class': 'image-card'}).img
            card['image'] = image.get('src')

            cards.append(card)

    return cards
